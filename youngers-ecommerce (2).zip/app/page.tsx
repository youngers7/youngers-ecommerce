import React from "react";
import Image from "next/image";

export default function HomePage() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      {/* Header */}
      <header className="p-6 flex items-center justify-between border-b border-white/10">
        <h1 className="text-2xl font-bold tracking-wide">YOUNGERS</h1>
        <nav className="space-x-4">
          <button className="bg-transparent hover:underline text-white">Home</button>
          <button className="bg-transparent hover:underline text-white">Shop</button>
          <button className="bg-transparent hover:underline text-white">Contact</button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center py-20 px-4">
        <h2 className="text-4xl font-extrabold mb-4">Born to Stay Young</h2>
        <p className="text-lg text-white/70 max-w-xl mx-auto mb-6">
          Découvre l’univers de Youngers — streetwear oversize inspiré des années 90/2000. Tracksuits puissants, logos marquants.
        </p>
        <button className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-6 py-3 rounded-2xl">Shop Now</button>
      </section>

      {/* Featured Product */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 p-8">
        <div className="bg-white text-black rounded-2xl p-4">
          <div className="aspect-square bg-gray-100 rounded-xl mb-4 overflow-hidden">
            <Image
              src="/tracksuit-hoodie.jpg"
              alt="Youngers Hoodie"
              width={500}
              height={500}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="aspect-square bg-gray-100 rounded-xl mb-4 overflow-hidden">
            <Image
              src="/tracksuit-bottom.jpg"
              alt="Youngers Jogging"
              width={500}
              height={500}
              className="w-full h-full object-cover"
            />
          </div>
          <h3 className="text-xl font-semibold">Tracksuit YOUNGERS - "Blue Flame" Edition</h3>
          <p className="text-sm text-gray-600">Oversize, noir, broderies bleues. 90s drip garanti.</p>
          <p className="text-lg font-bold mt-2">€89.99</p>
          <button className="mt-4 w-full bg-black text-white hover:bg-white hover:text-black border border-black px-4 py-2 rounded-lg">Ajouter au panier</button>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center p-6 border-t border-white/10 text-sm text-white/60">
        © 2025 Youngers. Tous droits réservés.
      </footer>
    </div>
  );
}
