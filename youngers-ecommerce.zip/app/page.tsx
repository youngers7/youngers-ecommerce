import React from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function HomePage() {
  return (
    <div className="bg-black text-white min-h-screen font-sans">
      {/* Header */}
      <header className="p-6 flex items-center justify-between border-b border-white/10">
        <h1 className="text-2xl font-bold tracking-wide">YOUNGERS</h1>
        <nav className="space-x-4">
          <Button variant="ghost" className="text-white">Home</Button>
          <Button variant="ghost" className="text-white">Shop</Button>
          <Button variant="ghost" className="text-white">Contact</Button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="text-center py-20 px-4">
        <h2 className="text-4xl font-extrabold mb-4">Born to Stay Young</h2>
        <p className="text-lg text-white/70 max-w-xl mx-auto mb-6">
          Découvre l’univers de Youngers — streetwear oversize inspiré des années 90/2000. Tracksuits puissants, logos marquants.
        </p>
        <Button className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-6 py-3 rounded-2xl">Shop Now</Button>
      </section>

      {/* Featured Product */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6 p-8">
        <Card className="bg-white text-black rounded-2xl">
          <CardContent className="p-4">
            <div className="aspect-square bg-gray-100 rounded-xl mb-4 overflow-hidden">
              <Image
                src="/tracksuit-hoodie.jpg"
                alt="Youngers Hoodie"
                width={500}
                height={500}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-square bg-gray-100 rounded-xl mb-4 overflow-hidden">
              <Image
                src="/tracksuit-bottom.jpg"
                alt="Youngers Jogging"
                width={500}
                height={500}
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="text-xl font-semibold">Tracksuit YOUNGERS - "Blue Flame" Edition</h3>
            <p className="text-sm text-gray-600">Oversize, noir, broderies bleues. 90s drip garanti.</p>
            <p className="text-lg font-bold mt-2">€89.99</p>
            <Button className="mt-4 w-full bg-black text-white hover:bg-white hover:text-black border border-black">Ajouter au panier</Button>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="text-center p-6 border-t border-white/10 text-sm text-white/60">
        © 2025 Youngers. Tous droits réservés.
      </footer>
    </div>
  );
}
